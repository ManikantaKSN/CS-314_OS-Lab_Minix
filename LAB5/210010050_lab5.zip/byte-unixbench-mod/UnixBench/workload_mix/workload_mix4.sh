./arithoh.sh &
./fstime.sh &
./arithoh.sh &
./syscall.sh &
./arithoh.sh &
wait